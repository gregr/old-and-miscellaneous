// line.h
// Gregory Rosenblatt
// 2/16/05

#ifndef Uriel_Line_H_
#define Uriel_Line_H_

#include "util/coord.h"

namespace Uriel {

	/** Represents a line in two-dimensional space. */
	struct Line {
		Line()	{}
		Line(const Coord& c1, const Coord& c2)
			: a(c1), b(c2)	{}
		Coord	a, b;
	};
}

#endif
