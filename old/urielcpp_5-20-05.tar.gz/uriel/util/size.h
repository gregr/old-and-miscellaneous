// size.h
// Gregory Rosenblatt
// 5/10/05

#ifndef Uriel_Size_H_
#define Uriel_Size_H_

#include "util/scalarpair.h"
#include "util/scalar.h"

namespace Uriel {

	/** A pair of dimensions representing a size. */
	typedef ScalarPair<SizeScalar>	Size;
}

#endif
