// output.h
// Gregory Rosenblatt
// 4/22/05

#ifndef Uriel_Python_Output_H_
#define Uriel_Python_Output_H_

namespace Uriel {

	namespace Python {

		/** Provided for the interpreter to print output. */
		void PrintString(const char* str);
	}
}

#endif
