// fontdata.h
// Gregory Rosenblatt
// 5/10/05

#ifndef Uriel_Graphics_Config_FONTDATA_H_
#define Uriel_Graphics_Config_FONTDATA_H_

// provide Raster::Font and TextSurface utilities
#include "raster/textsurface.h"
// provide Raster::FontContext
#include "raster/fontcontext.h"

#endif
