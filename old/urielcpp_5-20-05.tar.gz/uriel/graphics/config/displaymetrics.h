// displaymetrics.h
// Gregory Rosenblatt
// 5/9/05

#ifndef Uriel_Graphics_Config_DISPLAYMETRICS_H_
#define Uriel_Graphics_Config_DISPLAYMETRICS_H_

// provide DisplayMetrics
// Raster::DisplayMetrics must provide:
// Width(), Height()
#include "raster/display.h"

#endif
