// makepoweroftwo.h
// Gregory Rosenblatt
// 3/16/05

#ifndef Uriel_MakePowerOfTwo_H_
#define Uriel_MakePowerOfTwo_H_

namespace Uriel {

	/** Gets the first power of two larger than the given dimension. */
	inline unsigned int MakePowerOfTwo(unsigned int dimension) {
		unsigned int expansion = 1;
		while (expansion < dimension)
			expansion <<= 1;
		return expansion;
	}
}

#endif
