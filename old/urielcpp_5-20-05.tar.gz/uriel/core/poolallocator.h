// poolallocator.h
// Gregory Rosenblatt
// 5/18/05

#ifndef Uriel_PoolAllocator_H_
#define Uriel_PoolAllocator_H_

#define URIEL_USE_STD_ALLOCATOR
//#define URIEL_USE_BOOST_POOL_ALLOCATOR
// add gnu pool allocators?

#ifdef URIEL_USE_BOOST_POOL_ALLOCATOR
#include <boost/pool/pool_alloc.hpp>
#endif
#ifdef URIEL_USE_STD_ALLOCATOR
#include <memory>
#endif

namespace Uriel {

	template <typename T>
	struct PoolAllocator {
#ifdef URIEL_USE_BOOST_POOL_ALLOCATOR
		typedef boost::pool_allocator<T>	Type;
		typedef boost::fast_pool_allocator<T>	FastType;
#endif
#ifdef URIEL_USE_STD_ALLOCATOR
		typedef std::allocator<T>	Type;
		typedef std::allocator<T>	FastType;
#endif
	};
}

#endif
