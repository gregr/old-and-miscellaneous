// getfirstline.h
// Gregory Rosenblatt
// 3/22/05

#ifndef Uriel_GetFirstLine_H_
#define Uriel_GetFirstLine_H_

#include "pooledstring.h"

namespace Uriel {

	/** Gets a substring that is the first line of the given string. */
	inline PooledString GetFirstLine(const PooledString& str) {
		return str.substr(0, str.find_first_of('\n'));
	}
}

#endif
