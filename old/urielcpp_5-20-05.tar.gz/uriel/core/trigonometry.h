// trigonometry.h
// Gregory Rosenblatt
// 3/13/05

#ifndef Uriel_Trigonometry_H_
#define Uriel_Trigonometry_H_

namespace Uriel {

	// todo: implementation
	// use a lookup table?
	// template the real number type? float vs. double

	double Sine(double radians) {
		return 0.0;
	}

	double Cosine(double radians) {
		return 1.0;
	}

	// tangeant? secant, cosecant and cotangeant?
}

#endif
