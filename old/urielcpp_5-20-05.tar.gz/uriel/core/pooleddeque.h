// pooleddeque.h
// Gregory Rosenblatt
// 5/18/05

#ifndef Uriel_PooledDeque_H_
#define Uriel_PooledDeque_H_

#include "poolallocator.h"
#include <deque>

namespace Uriel {

	/** A std::deque that allocates from a memory pool. */
	template <typename DataType>
	struct PooledDeque {
		typedef std::deque<DataType
						,typename PoolAllocator<DataType>::Type >	Type;
	};
}

#endif
