// handleexception.h
// Gregory Rosenblatt
// 11/21/04

#ifndef Uriel_HandleException_H_
#define Uriel_HandleException_H_

#include <iostream>
#include <exception>

namespace Uriel {

	/** The standard exception handler. */
	inline void HandleException() {
		try {
			throw;	// rethrow the exception to see what type it is
		}
		catch (const std::exception& e) {
			std::cerr << "Error: " << e.what() << std::endl;
		}
		catch (...) {
			std::cerr << "Unhandled exception!" << std::endl;
		}
	}
}

#endif
