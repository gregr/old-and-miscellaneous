// keyboard.h
// Gregory Rosenblatt
// 5/6/05

#ifndef Uriel_Gui_Config_KEYBOARD_H_
#define Uriel_Gui_Config_KEYBOARD_H_

// input library already implements the necessities
// also in the proper namespace Uriel::Input
#include "input/keyinfo.h"

#endif
