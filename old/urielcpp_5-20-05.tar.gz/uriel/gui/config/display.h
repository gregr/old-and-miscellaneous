// display.h
// Gregory Rosenblatt
// 5/10/05

#ifndef Uriel_Gui_Config_DISPLAY_H_
#define Uriel_Gui_Config_DISPLAY_H_

// provide Raster::DisplayMetrics
#include "raster/display.h"
// provide Graphics::SetOrthoViewport()
#include "graphics/setorthoviewport.h"

#endif
