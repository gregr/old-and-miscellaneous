// font.h
// Gregory Rosenblatt
// 5/10/05

#ifndef Uriel_Gui_Config_FONT_H_
#define Uriel_Gui_Config_FONT_H_

// provide Graphics::ImageFontHandle and related functions
#include "graphics/imagefontmanager.h"

#endif
