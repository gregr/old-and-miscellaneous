// clipper.h
// Gregory Rosenblatt
// 5/10/05

#ifndef Uriel_Gui_Config_CLIPPER_H_
#define Uriel_Gui_Config_CLIPPER_H_

// provides Graphics::Clipper and Graphics::ClipRegion
#include "graphics/clipper.h"

#endif
