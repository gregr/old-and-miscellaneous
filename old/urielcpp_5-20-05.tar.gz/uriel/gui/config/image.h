// image.h
// Gregory Rosenblatt
// 5/10/05

#ifndef Uriel_Gui_Config_IMAGE_H_
#define Uriel_Gui_Config_IMAGE_H_

// provide Graphics::ImageHandle and Graphics::ImageRegion
#include "graphics/imagemanager.h"
#include "graphics/imageregion.h"

#endif
