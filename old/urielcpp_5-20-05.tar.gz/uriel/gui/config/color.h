// color.h
// Gregory Rosenblatt
// 5/10/05

#ifndef Uriel_Gui_Config_COLOR_H_
#define Uriel_Gui_Config_COLOR_H_

// provide Graphics::Color and associated functions
#include "graphics/color.h"

#endif
