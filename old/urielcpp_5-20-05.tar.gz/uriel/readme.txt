required libraries:

sdl
sdl_image
sdl_ttf (uses freetype)

OpenGL
RakNet
python
boost

Libraries can be found at:
http://www.libsdl.org
http://www.boost.org
http://www.python.org
http://www.rakkarsoft.com

Makefile:

Either set the BOOST environment variable to your boost directory
-OR-
change the makefile's BOOSTDIR variable to your boost directory.